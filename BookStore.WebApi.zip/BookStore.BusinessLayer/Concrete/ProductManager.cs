﻿using BookStore.BusinessLayer.Abstract;
using BookStore.DataAccessLayer.Abstract;
using BookStore.EntityLayer.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.BusinessLayer.Concrete
{
    public class ProductManager : IProductService
    {
        private readonly IProductDal _productDal;

        public ProductManager(IProductDal productDal)
        {
            _productDal = productDal;
        }

        public void TAdd(Product entity)
        {
            _productDal.Add(entity);
        }

        public void TDelete(int id)
        {
            _productDal.Delete(id);
        }

        public List<Product> TGetAll()
        {
            return _productDal.GetAll();
        }

        public Product TGetById(int id)
        {

            return _productDal.GetById(id);
        }

        public List<Product> TGetProductByCategory(int id)
        {
            return _productDal.GetProductByCategory(id);
        }

        public int TGetProductCount()
        {
            return _productDal.GetProductCount();
        }

        public void TUpdate(Product entity)
        {
            _productDal.Update(entity);
        }
    }
}
